/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pago;

/**
 *
 * @author adminroot
 */
public class Credito extends Pago {

    private String numTarjeta;
    private int mesCad;
    private int anyoCad;
    private int codSeg;

    @Override
    public String muetraPago() {
        String salida = "";

        return salida;
    }

}
